// ✅ StudentProfile backend API routes using create_database.sql
const express = require("express");
const db = require("../db");
const router = express.Router();

// Get basic student profile info
router.get("/:studentId/info", (req, res) => {
  const { studentId } = req.params;
  const query = `
    SELECT fname, lname, email, advisor, staff
    FROM student
    WHERE student_id = ?
  `;
  db.query(query, [studentId], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    if (results.length === 0) return res.status(404).json({ error: "Student not found" });

    const row = results[0];
    res.json({
      name: `${row.fname} ${row.lname}`,
      email: row.email,
      advisor: row.advisor,
      staff: row.staff
    });
  });
});

// Get activity radar data (literacy)
router.get("/:studentId/activity", (req, res) => {
  const { studentId } = req.params;
  const query = `
    SELECT skill_name AS label, SUM(hour_score) AS value
    FROM activity
    WHERE student_id = ? AND skill_category = 'literacy'
    GROUP BY skill_name
  `;
  db.query(query, [studentId], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

// Get skills radar data (soft skills)
router.get("/:studentId/skills", (req, res) => {
  const { studentId } = req.params;
  const query = `
    SELECT skill_name AS label, SUM(hour_score) AS value
    FROM activity
    WHERE student_id = ? AND skill_category = 'soft_skill'
    GROUP BY skill_name
  `;
  db.query(query, [studentId], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

// Get assignment submission stats
router.get("/:studentId/submissions", (req, res) => {
  const { studentId } = req.params;
  const query = `
    SELECT 
      SUM(CASE WHEN submit_date IS NULL THEN 1 ELSE 0 END) AS no_submission,
      SUM(CASE WHEN submit_date > due_date THEN 1 ELSE 0 END) AS late,
      SUM(CASE WHEN submit_date <= due_date THEN 1 ELSE 0 END) AS on_time
    FROM assignment_submit
    WHERE class_list_id IN (
      SELECT class_list_id FROM class_list WHERE student_id = ?
    )
  `;
  db.query(query, [studentId], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    const row = results[0];
    res.json([
      { label: "On Time", value: row.on_time },
      { label: "Late", value: row.late },
      { label: "No submission", value: row.no_submission }
    ]);
  });
});

// Get attendance stats
router.get("/:studentId/attendance", (req, res) => {
  const { studentId } = req.params;
  const query = `
    SELECT 
      SUM(CASE WHEN attendance_status = 'present' THEN 1 ELSE 0 END) AS present,
      SUM(CASE WHEN attendance_status = 'late' THEN 1 ELSE 0 END) AS late,
      SUM(CASE WHEN attendance_status = 'absent' THEN 1 ELSE 0 END) AS absent
    FROM attendance
    WHERE class_list_id IN (
      SELECT class_list_id FROM class_list WHERE student_id = ?
    )
  `;
  db.query(query, [studentId], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    const row = results[0];
    res.json([
      { label: "Present", value: row.present },
      { label: "Late", value: row.late },
      { label: "Absent", value: row.absent }
    ]);
  });
});

module.exports = router;